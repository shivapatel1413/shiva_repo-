import apache_beam as beam

def run():
    # Define the pipeline
    with beam.Pipeline() as pipeline:
        # Create a PCollection with the words "Hello" and "World"
        words = pipeline | 'Create' >> beam.Create(['Hello', 'World'])

        # Join the words with a space
        joined_words = (
            words
            | 'JoinWords' >> beam.CombineGlobally(lambda elements: ' '.join(elements))
        )

        # Print the joined words
        joined_words | 'Print' >> beam.Map(print)

if __name__ == '__main__':
    run()
