from pyspark.sql import SparkSession


spark = SparkSession.builder \
    .appName("Shiva_app") \
    .getOrCreate()
df_order=spark.read.csv("gs://my-dev-bucket_1322/SourceBucket-Zn/orders.csv",header=True)
df_order.show()

df_customers=spark.read.csv("gs://my-dev-bucket_1322/SourceBucket-Zn/customer.csv",header=True)
df_customers.show()

#join two df on customer_id

inner_df=df_order.join(df_customers,on='customer_id',how='inner')
inner_df.show()

#For each customer, calculates:
#Total amount spent
#First purchase date
#Last purchase date
#Number of purchases

from pyspark.sql.functions import avg,count,min,max,sum
from pyspark.sql.functions import sum, min, max

inner_df.groupBy('customer_id').agg(
    sum('amount').alias('total_spent_amount'),
    min('purchase_date').alias('minimum_purchase_date'),
    max('purchase_date').alias('maximum_purchase_date'),
    count('order_id').alias('count_of_purchase'),
    
).show()


#Average days between purchases (for customers with >1 purchase)
from pyspark.sql.window import Window
from pyspark.sql.functions import datediff,lag,col

Window_spec=Window.partitionBy('customer_id').orderBy('purchase_date')
inner_df_lag=inner_df.withColumn('prev_purchase_date',lag('purchase_date').over(Window_spec))
inner_df_lag.show()

#calculate the datediff

diff_inner_df=inner_df_lag.withColumn('date_difference',datediff(col('purchase_date'),col('prev_purchase_date')))
diff_inner_df.show()

filter_diff_df=diff_inner_df.filter(diff_inner_df.date_difference.isNotNull())
filter_diff_df.show()

result=filter_diff_df.filter(col('country')== 'USA')
final_df=result.groupBy('customer_id') \
.agg(avg('date_difference').alias('avg_days_between_purchases'), \
     count('*').alias('purchase_intervals'))

final_df.filter(col('purchase_intervals')>=1) \
.orderBy(col('avg_days_between_purchases').asc()).show()


