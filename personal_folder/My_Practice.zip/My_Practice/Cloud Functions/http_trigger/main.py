import functions_framework
from google.cloud import bigquery
from flask import jsonify

@functions_framework.http
def query_bq(request):
    client = bigquery.Client()

    query = """
        SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER, HIRE_DATE, 
               JOB_ID, SALARY, COMMISSION_PCT, MANAGER_ID, DEPARTMENT_ID
        FROM `etl-project-467506.personal_dev.employee_tb`
    """

    query_job = client.query(query)
    results = query_job.result()

    output = [
        {
            "EMPLOYEE_ID": row.EMPLOYEE_ID,
            "FIRST_NAME": row.FIRST_NAME,
            "LAST_NAME": row.LAST_NAME,
            "EMAIL": row.EMAIL,
            "PHONE_NUMBER": row.PHONE_NUMBER,
            "HIRE_DATE": str(row.HIRE_DATE),
            "JOB_ID": row.JOB_ID,
            "SALARY": row.SALARY,
            "COMMISSION_PCT": row.COMMISSION_PCT,
            "MANAGER_ID": row.MANAGER_ID,
            "DEPARTMENT_ID": row.DEPARTMENT_ID
        }
        for row in results
    ]

    return jsonify({"results": output})
