import os
import json
from google.cloud import pubsub_v1
import requests

# Set environment variables OR replace directly in code
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "962675e75ed042beb8be72f244c241d1")
PROJECT_ID = os.getenv("GCP_PROJECT", "etl-project-467506")
TOPIC_ID = "news-articles"

def fetch_news():
    url = f"https://newsapi.org/v2/top-headlines?country=us&pageSize=5&apiKey={NEWS_API_KEY}"
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"NewsAPI error: {response.text}")

    return response.json().get("articles", [])

def publish_to_pubsub(articles):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(PROJECT_ID, TOPIC_ID)

    for article in articles:
        data = {
            "title": article["title"],
            "source": article["source"]["name"],
            "url": article["url"],
            "published_at": article["publishedAt"]
        }
        future = publisher.publish(topic_path, json.dumps(data).encode("utf-8"))
        print(f"Published: {data['title']}")

def main():
    print("Fetching news...")
    articles = fetch_news()
    print(f"Fetched {len(articles)} articles.")

    print("Publishing to Pub/Sub...")
    publish_to_pubsub(articles)

if __name__ == "__main__":
    main()
