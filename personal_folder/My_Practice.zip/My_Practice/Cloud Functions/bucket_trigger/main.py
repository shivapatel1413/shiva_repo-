import csv
from google.cloud import storage
from google.cloud import bigquery

def query_bq(event, context):
    # Get bucket and file info from the event
    bucket_name = event['bucket']
    file_name = event['name']
    print(f"Triggered by file: {file_name} in bucket: {bucket_name}")

    # Only process .csv files
    if not file_name.endswith(".csv"):
        print("Skipping non-CSV file.")
        return

    # Initialize clients
    storage_client = storage.Client()
    bq_client = bigquery.Client()

    # Download file content
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)
    content = blob.download_as_text()

    # Parse CSV content
    reader = csv.DictReader(content.splitlines())
    rows_to_insert = []

    for row in reader:
        rows_to_insert.append({
            "EMPLOYEE_ID": row["EMPLOYEE_ID"],
            "FIRST_NAME": row["FIRST_NAME"],
            "LAST_NAME": row["LAST_NAME"]
        })

    # Define BigQuery table
    table_id = "etl-project-467506.personal_dev.employee"

    # Insert data into BigQuery
    errors = bq_client.insert_rows_json(table_id, rows_to_insert)

    if errors:
        print("❌ Errors while inserting to BigQuery:", errors)
    else:
        print("✅ Data loaded successfully into BigQuery.")
