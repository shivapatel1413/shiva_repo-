import requests
import os

NEWS_API_KEY = os.getenv("NEWS_API_KEY", "962675e75ed042beb8be72f244c241d1")
url = f"https://newsapi.org/v2/top-headlines?country=us&pageSize=5&apiKey={NEWS_API_KEY}"
response = requests.get(url)
print(response)
print(response.json().get("articles", []))
